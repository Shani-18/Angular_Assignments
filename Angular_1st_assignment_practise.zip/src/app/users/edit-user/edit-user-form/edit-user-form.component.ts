import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-user-form',
  templateUrl: './edit-user-form.component.html',
  styleUrls: ['./edit-user-form.component.css']
})
export class EditUserFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
