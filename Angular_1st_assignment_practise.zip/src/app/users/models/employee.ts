import { v4 } from 'uuid';

export class Employee {
  constructor(
    public id = v4(),
    public firstName: string = '',
    public lastName: string = '',
    public email: string = '',
    public salary: number = 0
  ) {}
}
