import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { UsersRoutingModule } from './users-routing.module';
import { AddUserComponent } from './add-user/add-user.component';
import { EditUserComponent } from './edit-user/edit-user.component';
import { ListUserComponent } from './list-user/list-user.component';
import { AddUserFormComponent } from './add-user/add-user-form/add-user-form.component';
import { ListUserFormComponent } from './list-user/list-user-form/list-user-form.component';
import { EditUserFormComponent } from './edit-user/edit-user-form/edit-user-form.component';
import { UserService } from './services/user.service';

@NgModule({
  declarations: [
    AddUserComponent,
    EditUserComponent,
    ListUserComponent,
    AddUserFormComponent,
    ListUserFormComponent,
    EditUserFormComponent,
  ],
  imports: [CommonModule, UsersRoutingModule],
  providers: [UserService],
})
export class UsersModule {}
