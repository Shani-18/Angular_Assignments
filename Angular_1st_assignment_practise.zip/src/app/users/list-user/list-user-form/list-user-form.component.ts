import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-list-user-form',
  templateUrl: './list-user-form.component.html',
  styleUrls: ['./list-user-form.component.css']
})
export class ListUserFormComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
