import { Component, ElementRef, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { v4 } from 'uuid';
import { Employee } from '../../models/employee';

@Component({
  selector: 'app-add-user-form',
  templateUrl: './add-user-form.component.html',
  styleUrls: ['./add-user-form.component.css'],
})
export class AddUserFormComponent implements OnInit {
  @ViewChild('firstName', { static: false }) firstName!: ElementRef;
  @ViewChild('lastName', { static: false }) lastName!: ElementRef;
  @ViewChild('email', { static: false }) email!: ElementRef;
  @ViewChild('salary', { static: false }) salary!: ElementRef;

  @Output('employeeData') employeeData:EventEmitter<Employee>=new EventEmitter<Employee>;
  constructor() {}

  ngOnInit(): void {}
  generateAddEmployeeData() {
    const employee = new Employee();
    employee.id = v4();
    employee.firstName = this.firstName.nativeElement.value;
    employee.lastName = this.lastName.nativeElement.value;
    employee.email = this.email.nativeElement.value;
    employee.salary = this.salary.nativeElement.value;
    console.log(employee);

    this.employeeData.emit(employee)
  }
}
