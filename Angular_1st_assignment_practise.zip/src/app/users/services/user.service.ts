import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { Employee } from '../models/employee';

@Injectable({
  providedIn: 'root',
})
export class UserService {
  employeeList: Employee[] = [];
  localItem: string | null;

  constructor(private router: Router) {
    this.localItem = localStorage.getItem('employeesData');
    this.employeeList =
      this.localItem === null ? [] : JSON.parse(this.localItem);
  }
  addEmployee(employee: Employee) {
    this.employeeList.push(employee);
    localStorage.setItem('employeesData', JSON.stringify(this.employeeList));
    console.log(this.employeeList);

    this.router.navigate(['/users/list']);
  }
}
