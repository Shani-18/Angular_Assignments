import { Component, OnInit } from '@angular/core';
import { User } from '../models/user';
import { AccountsService } from '../services/accounts.service';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css'],
})
export class SignupComponent implements OnInit {
  constructor(private accountsServices: AccountsService) {}

  ngOnInit(): void {}
  userData(userData: User) {
    this.accountsServices.addUser(userData);
    // console.log('signup', userData);
  }
}
