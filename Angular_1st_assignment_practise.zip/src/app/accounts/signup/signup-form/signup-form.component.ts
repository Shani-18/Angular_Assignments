import {
  Component,
  ElementRef,
  EventEmitter,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import { NgForm } from '@angular/forms';

import { User } from 'src/app/accounts/models/user';

import { v4 } from 'uuid';

@Component({
  selector: 'app-signup-form',
  templateUrl: './signup-form.component.html',
  styleUrls: ['./signup-form.component.css'],
})
export class SignupFormComponent implements OnInit {
  // // form data using local reference
  // @ViewChild('firstName', { static: false }) firstName!: ElementRef;
  // @ViewChild('lastName', { static: false }) lastName!: ElementRef;
  // @ViewChild('email', { static: false }) email!: ElementRef;
  // @ViewChild('password', { static: false }) password!: ElementRef;
  // @ViewChild('confirmPassword', { static: false }) confirmPassword!: ElementRef;
  // @ViewChild('isActive', { static: false }) isActive!: ElementRef;

  @Output('userData') userData: EventEmitter<User> = new EventEmitter<User>();
  constructor() {}

  @ViewChild('signUpDataForm') signUpData!: NgForm;

  ngOnInit(): void {}

  generateUserSignUpData() {
    const user: User = this.signUpData.value;
    user.id = v4();

    this.userData.emit(user);
    console.log('formData', this.signUpData.form);

    console.log('form user', user);
    this.signUpData.reset();
    // user.firstName = this.signUpData.value.firstName;
    // user.lastName = this.signUpData.value.lastName;
    // user.email = this.signUpData.value.email;
    // user.password = this.signUpData.value.password;
    // user.isActive = this.signUpData.value.isActive ;
  }
  // fillData() {
  //   this.signUpData.form.patchValue({
  //     firstName: 'Usama',
  //     lastName: 'Aslam',
  //     email: 'abc@gmail.com',
  //   });
  // }
}
