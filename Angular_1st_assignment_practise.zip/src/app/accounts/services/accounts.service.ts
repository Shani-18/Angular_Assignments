import { Injectable } from '@angular/core';
import { Router } from '@angular/router';
import { LoginUser } from '../models/login-user';
import { User } from '../models/user';

@Injectable({
  providedIn: 'root',
})
export class AccountsService {
  userList: User[] = [];
  localItem: string | null;

  constructor(private router: Router) {
    this.localItem = localStorage.getItem('usersData');
    this.userList = this.localItem === null ? [] : JSON.parse(this.localItem);
  }
  addUser(user: User) {
    this.userList.push(user);
    localStorage.setItem('usersData', JSON.stringify(this.userList));
    this.router.navigate(['/accounts/login']);
  }
  userAuthentication(user: LoginUser) {
    const checkUser = this.userList.find((x) => {
      return x.email === user.email;
    });
    checkUser != undefined
      ? this.router.navigate(['/'])
      : this.router.navigate(['/accounts/login']);
  }
}
