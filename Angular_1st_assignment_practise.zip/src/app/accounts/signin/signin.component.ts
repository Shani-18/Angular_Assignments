import { Component, OnInit } from '@angular/core';
import { LoginUser } from '../models/login-user';
import { AccountsService } from '../services/accounts.service';

@Component({
  selector: 'app-signin',
  templateUrl: './signin.component.html',
  styleUrls: ['./signin.component.css'],
})
export class SigninComponent implements OnInit {
  constructor(private accountsServices: AccountsService) {}

  ngOnInit(): void {}
  generateUserLoginData(userLoginData: LoginUser) {
    console.log(userLoginData);
    this.accountsServices.userAuthentication(userLoginData);
  }
}
