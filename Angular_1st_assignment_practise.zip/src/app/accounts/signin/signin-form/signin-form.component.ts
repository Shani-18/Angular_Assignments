import {
  Component,
  ElementRef,
  EventEmitter,
  OnInit,
  Output,
  ViewChild,
} from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { LoginUser } from '../../models/login-user';
import { User } from '../../models/user';
import { AccountsService } from '../../services/accounts.service';

@Component({
  selector: 'app-signin-form',
  templateUrl: './signin-form.component.html',
  styleUrls: ['./signin-form.component.css'],
})
export class SigninFormComponent implements OnInit {
  // @ViewChild('email') email!: ElementRef;
  // @ViewChild('password') password!: ElementRef;

  @Output('userLoginData') userLoginData: EventEmitter<LoginUser>;
  loginDataUser: any;

  constructor() {
    this.userLoginData = new EventEmitter<LoginUser>();
  }

  ngOnInit(): void {
    this.createForm();
  }
  generateUserLoginData() {
    console.log('this.loginDataUser', this.loginDataUser);
    const user: LoginUser = this.loginDataUser.value;
    console.log('user', user);
    this.userLoginData.emit(user);
  }
  createForm() {
    const form: FormBuilder = new FormBuilder();
    this.loginDataUser = form.group({
      email: [
        '',
        Validators.compose([
          Validators.required,
          Validators.minLength(5),
          Validators.maxLength(60),
        ]),
      ],
      password: [
        '',
        Validators.compose([Validators.required, Validators.minLength(8)]),
      ],
    });
  }
}
