import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AccountsRoutingModule } from './accounts-routing.module';
import { SigninComponent } from './signin/signin.component';
import { SignupComponent } from './signup/signup.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { SigninFormComponent } from './signin/signin-form/signin-form.component';
import { SignupFormComponent } from './signup/signup-form/signup-form.component';
import { ForgotPasswordFormComponent } from './forgot-password/forgot-password-form/forgot-password-form.component';
import { AccountsService } from './services/accounts.service';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    SigninComponent,
    SigninFormComponent,
    SignupFormComponent,
    SignupComponent,
    ForgotPasswordFormComponent,
    ForgotPasswordComponent,
  ],
  providers: [AccountsService],
  imports: [
    CommonModule,
    AccountsRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ],
})
export class AccountsModule {}
