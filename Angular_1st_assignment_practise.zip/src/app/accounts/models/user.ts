import { v4 } from 'uuid';

export class User {
  constructor(
    public id: String = v4(),
    public firstName: String = '',
    public lastName: String = '',
    public email: String = '',
    public password: String = '',
    public isActive: boolean = false
  ) {}
}
