export class LoginUser {
  public email: string = '';
  public password: string = '';
}
